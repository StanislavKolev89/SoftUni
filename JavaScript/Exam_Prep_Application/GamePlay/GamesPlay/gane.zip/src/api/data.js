import * as api from './api.js';
export const login = api.login;
export const register = api.register;
export const logout = api.logout;


export async function getAllGames() {
    return api.get('/data/games?sortBy=_createdOn%20desc');
}

export async function getlatestGames() {
    return api.get('/data/games?sortBy=_createdOn%20desc&distinct=category');
}

export async function createNewGame(gameBody) {
    return api.post('/data/games',gameBody);
}

export async function detailsForOneGame(gameId) {
    return api.get('/data/games/' + gameId);
}

export async function editSingleGame(gameId, gameBody) {
    return api.put('/data/games/' + gameId, gameBody);
}

export async function deleteSingleGame(gameId) {
    return api.del('/data/games/' + gameId);
}


