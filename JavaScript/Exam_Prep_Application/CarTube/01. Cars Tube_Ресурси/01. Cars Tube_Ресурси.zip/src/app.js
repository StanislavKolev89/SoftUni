import { logout } from "./api/data.js";
import { render } from "./lib.js";
import { page } from "./lib.js";
import { getUserData } from "./util.js";
import { listingsPage } from "./views/alllistings.js";
import { addCar } from "./views/create.js";
import { detailsPage } from "./views/details.js";
import { editPage } from "./views/edit.js";
import { homePage } from "./views/homeview.js";
import { loginPage } from "./views/login.js";
import { myPage } from "./views/mylistings.js";
import { registerPage } from "./views/register.js";


const mainSection = document.getElementById('site-content');
document.getElementById('logoutBtn').addEventListener('click', userLogout);
updateUserNav();

page(middleware);
page('/', homePage);
page('/login', loginPage);
page('/register', registerPage);
page('/details/:id', detailsPage);
page('/edit/:id',editPage);
page('/create',addCar);
page('/alllistings', listingsPage);
page('/mycars',myPage);

page.start();

function middleware(ctx, next) {
    ctx.updateUserNav = updateUserNav;
    ctx.render = (view) => render(view, mainSection);
    next();
}


function updateUserNav() {
    const userData = getUserData();
    if (userData) {
        document.getElementById('profile').style.display = 'block';
        document.getElementById('guest').style.display = 'none';
        document.getElementById('welcome').textContent = `Welcome, ${userData.username}`;
    } else {
        document.getElementById('profile').style.display = 'none';
        document.getElementById('guest').style.display = 'block';
    }
}

async function userLogout(ev) {
    ev.preventDefault();
    await logout();
    updateUserNav();
    page.redirect('/')
}

