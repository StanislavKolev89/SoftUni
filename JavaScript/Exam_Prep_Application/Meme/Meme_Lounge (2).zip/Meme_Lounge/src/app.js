
import { logout } from "./api/data.js";
import { page, render } from "./lib.js";

import { createPage } from "./views/create.js";
import { detailsPage } from "./views/details.js";
import { editPage } from "./views/edit.js";
import { homePage } from "./views/home.js";
import { loginPage } from "./views/login.js";
import { memePage } from "./views/meme.js";
import { profilePage } from "./views/profile.js";
import { registerPage } from "./views/register.js";

updateNav();
const main = document.querySelector('main');

page(middleWare);
page('/', homePage);
page('/create', createPage)
page('/memes', memePage);
page('/login', loginPage);
page('/details/:id', detailsPage);
page('/edit/:id',editPage);
page('/register', registerPage);
page('/profile',profilePage);

page.start();
document.getElementById('logoutBtn').addEventListener('click', onLogout);

function onLogout(){
   
    logout(); 
}

function middleWare(ctx, next) {
    ctx.updateNav = updateNav;
    ctx.render = (view) => render(view, main);

    next();
}

 function updateNav() {
    const userData = JSON.parse(sessionStorage.getItem('userData'));

    if (userData != null) {
        document.querySelector('.user').style.dispay = 'block';
        document.querySelector('.guest').style.display = 'none';
        document.querySelector('.user span').textContent = `Welcome, ${userData.email}`;
    } else {
        document.querySelector('.user').style.display = 'none';
        document.querySelector('.guest').style.display = 'block';
    }
}