
export async function getData (){
    return JSON.parse(sessionStorage.getItem('userData'));   
}

export async function removeData(){
 sessionStorage.removeItem('userData');
}

export async function setData(data){
   return sessionStorage.setItem('userData', JSON.stringify(data));
}