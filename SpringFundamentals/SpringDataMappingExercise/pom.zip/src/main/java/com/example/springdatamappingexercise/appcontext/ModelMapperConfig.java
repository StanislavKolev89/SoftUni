package com.example.springdatamappingexercise.appcontext;

import com.example.springdatamappingexercise.dto.GameAddDto;
import com.example.springdatamappingexercise.entity.Game;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeMap;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
public class ModelMapperConfig {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();
        TypeMap<GameAddDto, Game> typeMap = modelMapper.createTypeMap(GameAddDto.class, Game.class);
        typeMap.addMapping(GameAddDto::getThumbUrl ,Game::setImageUrl);

         return modelMapper;
    }
}
