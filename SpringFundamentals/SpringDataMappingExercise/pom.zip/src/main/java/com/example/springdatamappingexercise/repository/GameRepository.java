package com.example.springdatamappingexercise.repository;

import com.example.springdatamappingexercise.entity.Game;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface GameRepository extends JpaRepository<Game,Long> {

Game  findGameById(Long aLong);

    Game findGameByTitle(String gameName);
}
