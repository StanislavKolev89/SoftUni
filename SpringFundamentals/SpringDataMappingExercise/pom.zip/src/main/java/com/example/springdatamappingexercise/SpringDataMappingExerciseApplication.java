package com.example.springdatamappingexercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataMappingExerciseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringDataMappingExerciseApplication.class, args);
    }

}
