package com.example.springdatamappingexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataMappingExerciseApplicationTests {

    @Test
    void contextLoads() {
    }

}
