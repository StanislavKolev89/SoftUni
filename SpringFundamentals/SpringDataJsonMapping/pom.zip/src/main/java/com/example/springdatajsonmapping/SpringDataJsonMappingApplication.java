package com.example.springdatajsonmapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJsonMappingApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringDataJsonMappingApplication.class, args);
    }

}
