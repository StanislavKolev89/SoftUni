package com.example.springdatajsonmapping.service.impl;


import com.example.springdatajsonmapping.Paths.MyPaths;
import com.example.springdatajsonmapping.model.dto.ProductUserExportDto;
import com.example.springdatajsonmapping.model.dto.UserExportDto;
import com.example.springdatajsonmapping.model.dto.UserImportDto;
import com.example.springdatajsonmapping.model.entity.Product;
import com.example.springdatajsonmapping.model.entity.User;
import com.example.springdatajsonmapping.repository.UserRepository;
import com.example.springdatajsonmapping.service.UserService;
import com.example.springdatajsonmapping.util.ValidationUtilImpl;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;



@Service
public class UserServiceImpl implements UserService {

    private static final String USERS_FILE = "users.json";
    private final ModelMapper modelMapper;
    private final Gson gson;
    private final UserRepository userRepository;
    private final ValidationUtilImpl validationUtilImpl;

    @Autowired
    public UserServiceImpl(Gson gson, UserRepository userRepository, ValidationUtilImpl validationUtilImpl,ModelMapper modelMapper) {
        this.validationUtilImpl = validationUtilImpl;
        this.modelMapper = modelMapper;
        this.gson = gson;
        this.userRepository = userRepository;

    }

    @Override
    public void SeedUsers() throws IOException {
        if(userRepository.findAll().size()>0){
            return;
        }
        String users = Files.readString(Path.of(MyPaths.MAIN_PATH_FILES + USERS_FILE));

        UserImportDto[] userImportDtos = this.gson.fromJson(users,UserImportDto[].class);

   Arrays.stream(userImportDtos).filter(validationUtilImpl::isValid).
                map(userImportDto -> modelMapper.map(userImportDto, User.class)).collect(Collectors.toList()).forEach(userRepository::save);


    }

    @Override
    public User getRandomUser() {
         int range = ThreadLocalRandom.current().nextInt(0,userRepository.findAll().size()+1);
       return userRepository.findUserById((long) range).orElse(null);
    }

    @Override
    public List<UserExportDto> findAllUsersWithSoldProducts() {
        Set<User> allUsersWIthSoldProducts = userRepository.findAllUsersWIthSoldProducts();
        return allUsersWIthSoldProducts.stream().map(user -> {
            List<Product> sellingItems = user.getSellingItems();
            UserExportDto mappedUser = modelMapper.map(user, UserExportDto.class);
            List<ProductUserExportDto> collect = sellingItems.stream().map(item -> modelMapper.map(item, ProductUserExportDto.class)).collect(Collectors.toList());
            mappedUser.setSoldProducts(collect);
            return mappedUser;

        }).collect(Collectors.toList());

    }


}
