package com.example.springdatajsonmapping.service;


import com.example.springdatajsonmapping.model.dto.ProductExportDto;

import java.io.IOException;
import java.util.List;

public interface ProductService {
    void seedProducts() throws IOException;

    List<ProductExportDto> findAllProductsInRAnge();
}
