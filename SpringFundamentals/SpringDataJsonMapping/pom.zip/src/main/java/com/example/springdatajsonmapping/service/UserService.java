package com.example.springdatajsonmapping.service;

import com.example.springdatajsonmapping.model.dto.UserExportDto;
import com.example.springdatajsonmapping.model.entity.User;

import java.io.IOException;
import java.util.List;

public interface UserService {
    void SeedUsers() throws IOException;

    User getRandomUser();

    List<UserExportDto> findAllUsersWithSoldProducts();
}
