package com.example.springdatajsonmapping.Paths;

public class MyPaths {
    public static final String MAIN_PATH_FILES = "src/main/resources/files/";
    public static final String OUTPUT_PATH = "src/main/resources/files/output/";
}
