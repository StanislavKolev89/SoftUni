package com.example.springdatajsonmapping.repository;

import com.example.springdatajsonmapping.model.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import java.util.List;
import java.util.Optional;
import java.util.Set;

@SuppressWarnings("JpaQlInspection")
@Repository
public interface UserRepository extends JpaRepository<User,Long> {
    Optional<User> findUserById(long range);

    @Query(value = "SELECT * FROM product_shop_ex.users AS u JOIN product_shop_ex.product p on u.id = p.buyer_id",nativeQuery = true)
    Set<User> findAllUsersWIthSoldProducts();

}
