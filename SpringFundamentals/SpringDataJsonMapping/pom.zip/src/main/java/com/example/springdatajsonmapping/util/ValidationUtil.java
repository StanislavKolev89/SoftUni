package com.example.springdatajsonmapping.util;

public interface ValidationUtil {
    <E> boolean isValid (E entity);
 }
