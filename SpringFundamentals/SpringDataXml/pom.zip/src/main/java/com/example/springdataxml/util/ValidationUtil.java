package com.example.springdataxml.util;

public interface ValidationUtil {
    <T> boolean isValid(T entity);
}
