package com.example.springdataxml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataXmlApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringDataXmlApplication.class, args);
    }

}
