import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double d = Double.parseDouble(scanner.nextLine());
        System.out.println(d+ 0.04);
    }
}
