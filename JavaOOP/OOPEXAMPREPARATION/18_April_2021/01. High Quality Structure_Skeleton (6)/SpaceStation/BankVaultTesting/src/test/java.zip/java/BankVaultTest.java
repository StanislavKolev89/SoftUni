import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import javax.naming.OperationNotSupportedException;
import java.util.LinkedHashMap;
import java.util.Map;

public class BankVaultTest {

      private BankVault bankVault;
      private Map<String,Item> items;

      @Before
        public void  setUp(){
          bankVault = new BankVault();
          items = new LinkedHashMap<>();
          this.items.put("A1", null);
          this.items.put("A2", null);
          this.items.put("A3", null);
          this.items.put("A4", null);
          this.items.put("B1", null);
          this.items.put("B2", null);
          this.items.put("B3", null);
          this.items.put("B4", null);
          this.items.put("C1", null);
          this.items.put("C2", null);
          this.items.put("C3", null);
          this.items.put("C4", null);
      }


      @Test
    public void properCreatingBankVault(){
          Assert.assertEquals(bankVault.getVaultCells(),items);
          Assert.assertEquals(12,bankVault.getVaultCells().size());
      }

      @Test(expected = IllegalArgumentException.class)
    public void testAddingToNotExistingCell() throws OperationNotSupportedException {
          bankVault.addItem("E5", new Item("Gosho", "tasd"));
      }

    @Test(expected = OperationNotSupportedException.class)
    public void testAddingToExistingCell() throws OperationNotSupportedException {
          Item item = new Item("Gosho", "tasd");
        bankVault.addItem("A1", item);
        Assert.assertTrue(bankVault.getVaultCells().containsValue(item));
        bankVault.addItem("A1",item);
    }


    @Test(expected = IllegalArgumentException.class)
    public void testAddingToCellSameItem() throws OperationNotSupportedException {
        bankVault.addItem("A1", new Item("Gosho", "tasd"));
        bankVault.addItem("A1", new Item("Gosho", "tasd"));
    }
    @Test (expected = IllegalArgumentException.class)
    public void test_RemovingNonExistingCell(){

          Assert.assertEquals("Cell doesn't exists!", bankVault.removeItem("D14", new Item("asd","asd")));
    }
    @Test
    public void test_RemovingExistingCell() throws OperationNotSupportedException {
          Item item = new Item("test","id");
          bankVault.addItem("A3",item);

        Assert.assertEquals("Remove item:id successfully!",  bankVault.removeItem("A3",item));
    }

    @Test (expected = IllegalArgumentException.class)
    public void test_RemovingNonExistingItemInCell(){

        Assert.assertEquals("Item in that cell doesn't exists!", bankVault.removeItem("A2", new Item("asd","asd")));
    }

}