package bakery.repositories.interfaces;

import bakery.entities.bakedFoods.interfaces.BakedFood;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class FoodRepositoryImpl implements FoodRepository<BakedFood> {
    private Collection<BakedFood> foodList;

    public FoodRepositoryImpl() {
        this.foodList = new ArrayList<>();
    }


    @Override
    public BakedFood getByName(String name) {
        return foodList.stream().filter(bakedFood -> bakedFood.getName().equals(name)).findFirst().orElse(null);
    }

    @Override
    public Collection getAll() {
        return this.foodList;
    }

    @Override
    public void add(BakedFood bakedFood) {
        this.foodList.add(bakedFood);
    }


}
