package Military.interfaces;

import Military.entities.Corps;

public interface SpecialisedSoldier extends Private {
    Corps getCorps();
}
