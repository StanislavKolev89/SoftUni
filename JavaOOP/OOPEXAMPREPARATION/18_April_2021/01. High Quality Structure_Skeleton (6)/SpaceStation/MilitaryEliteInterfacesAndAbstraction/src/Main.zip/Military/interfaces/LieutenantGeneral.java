package Military.interfaces;

public interface LieutenantGeneral extends Private{
    void addPrivate(Private priv);
}
