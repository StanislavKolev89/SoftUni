package Military.interfaces;

public interface Repair {
    String getPartName();
    int getHoursWorked();
}
