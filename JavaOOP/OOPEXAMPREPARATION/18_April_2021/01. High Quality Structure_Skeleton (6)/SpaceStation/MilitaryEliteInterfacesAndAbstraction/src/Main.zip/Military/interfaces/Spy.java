package Military.interfaces;

public interface Spy extends Private{
    String getSpyNumber();
}
