package Military.entities;

public enum Corps {
    AIRFORCES,
    MARINES;
}
