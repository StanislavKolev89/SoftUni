package Military.entities;

public enum MissionState {
    IN_PROGRESS,
    FINISHED
}
