package Military.interfaces;

public interface Private extends Soldier{
    double getSalary();
}
