package Military.interfaces;

public interface Soldier {
    int getId();
    String firstName();
    String lastName();
}
