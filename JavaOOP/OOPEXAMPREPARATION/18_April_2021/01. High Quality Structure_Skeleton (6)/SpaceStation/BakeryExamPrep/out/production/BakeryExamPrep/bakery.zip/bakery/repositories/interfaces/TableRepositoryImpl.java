package bakery.repositories.interfaces;

import java.util.Collection;

public class TableRepositoryImpl implements TableRepository{
    @Override
    public Collection getAll() {
        return null;
    }

    @Override
    public void add(Object o) {

    }

    @Override
    public Object getByNumber(int number) {
        return null;
    }
}
