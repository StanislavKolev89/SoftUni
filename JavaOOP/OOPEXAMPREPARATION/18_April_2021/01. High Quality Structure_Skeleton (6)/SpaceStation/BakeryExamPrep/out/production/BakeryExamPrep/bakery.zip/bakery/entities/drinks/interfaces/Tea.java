package bakery.entities.drinks.interfaces;

public class Tea extends BaseDrink{
    protected Tea(String name, int portion, double price, String brand) {
        super(name, portion, price, brand);
    }
}
