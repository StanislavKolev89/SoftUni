package bakery.entities.bakedFoods.interfaces;

public class Bread extends BaseFood{
    protected Bread(String name, double portion, double price) {
        super(name, portion, price);
    }
}
