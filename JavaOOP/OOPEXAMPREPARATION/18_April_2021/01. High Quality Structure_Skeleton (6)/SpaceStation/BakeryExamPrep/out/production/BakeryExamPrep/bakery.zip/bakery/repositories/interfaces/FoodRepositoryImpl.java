package bakery.repositories.interfaces;

import java.util.Collection;

public class FoodRepositoryImpl implements FoodRepository{
    @Override
    public Object getByName(String name) {
        return null;
    }

    @Override
    public Collection getAll() {
        return null;
    }

    @Override
    public void add(Object o) {

    }
}
