package spaceStation.models.astronauts;

public class Geodesist extends BaseAstronaut {
    private static final int OXYGEN = 50;

    public Geodesist(String name) {
        super(name, OXYGEN);
    }
}
