public class Vegetable extends Food{

    protected Vegetable(int quantity) {
        super(quantity);
    }
}
