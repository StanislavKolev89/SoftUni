public class Meat extends Food{
    protected Meat(int quantity) {
        super(quantity);
    }
}
