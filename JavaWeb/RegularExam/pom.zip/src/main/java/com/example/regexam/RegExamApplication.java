package com.example.regexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegExamApplication {

    public static void main(String[] args) {
        SpringApplication.run(RegExamApplication.class, args);
    }

}
