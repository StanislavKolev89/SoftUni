package com.example.regexam.model.enums;



public enum StyleEnum {
    POP,ROCK,JAZZ
}