package com.example.regexam.controller;

import com.example.regexam.service.SongService;
import com.example.regexam.util.CurrentUser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    private final SongService songService;
    private final CurrentUser currentUser;

    public HomeController(SongService songService, CurrentUser currentUser) {
        this.songService = songService;
        this.currentUser = currentUser;
    }

    @GetMapping("/")
    public String indexPage(){
        if(currentUser.getId()!=null){
            return "home";
        }
        return "index";
    }

    @GetMapping("/home")
    public String homePage(Model model){

        model.addAttribute("popSongs",songService.findPopSongs());
        model.addAttribute("rockSongs",songService.findRockSongs());
        model.addAttribute("jazzSongs",songService.findJazzSongs());
        return "home";
    }


}
