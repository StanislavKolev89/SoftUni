package com.example.regexam.service.impl;

import com.example.regexam.model.entity.SongEntity;
import com.example.regexam.model.service.AddSongService;
import com.example.regexam.repository.SongRepository;
import com.example.regexam.service.SongService;
import com.example.regexam.service.StyleService;
import com.example.regexam.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SongServiceImpl implements SongService {

    private final ModelMapper modelMapper;
    private final SongRepository songRepository;
    private final StyleService styleService;
    private final UserService userService;

    public SongServiceImpl(ModelMapper modelMapper, SongRepository songRepository, StyleService styleService, UserService userService) {
        this.modelMapper = modelMapper;
        this.songRepository = songRepository;
        this.styleService = styleService;
        this.userService = userService;
    }

    @Override
    public List<SongEntity> findJazzSongs() {
        return songRepository.findJazzSongs();
    }

    @Override
    public void saveSong(AddSongService song) {
        SongEntity songEntity = modelMapper.map(song, SongEntity.class);

        songEntity.setStyle(styleService.findByStyleEnum(song.getStyle()));
        songRepository.save(songEntity);

    }

    @Override
    public List<SongEntity> findPopSongs() {
        return songRepository.findPopSongs();
    }

    @Override
    public List<SongEntity> findRockSongs() {
        return songRepository.findRockSongs();
    }


}
