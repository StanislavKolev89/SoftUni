package com.example.regexam.service.impl;

import com.example.regexam.model.entity.SongEntity;
import com.example.regexam.model.entity.UserEntity;
import com.example.regexam.model.service.LoginUserServiceModel;
import com.example.regexam.model.service.RegisterUserServiceModel;
import com.example.regexam.repository.UserRepository;
import com.example.regexam.service.SongService;
import com.example.regexam.service.UserService;
import com.example.regexam.util.CurrentUser;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final CurrentUser currentUser;
    private final SongService songService;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper, CurrentUser currentUser, SongService songService) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.currentUser = currentUser;
        this.songService = songService;
    }

    @Override
    public boolean findByUsernameAndPassword(String username, String password) {
        return userRepository.findByUsernameAndPassword(username, password) == null;
    }

    @Override
    public void registerUser(RegisterUserServiceModel regUser) {
        userRepository.save(modelMapper.map(regUser, UserEntity.class));
    }

    @Override
    public void login(LoginUserServiceModel loginModel) {

        currentUser.setUsername(loginModel.getUsername());
        currentUser.setId(userRepository.findByUsername(loginModel.getUsername()).getId());

    }

    @Override
    public UserEntity findById() {
        return userRepository.findById(currentUser.getId()).orElse(null);
    }

    @Override
    public void addPlaylist(String id) {
        UserEntity userEntity = userRepository.findById(currentUser.getId()).get();
        List<SongEntity> songToAdd= addSongs(id);
        userEntity.getPlaylist().add((SongEntity) songToAdd);
    }

    private List<SongEntity> addSongs(String id) {
        List<SongEntity> songEntities=null;
        switch (id){
            case"POP"-> songEntities=songService.findPopSongs();
            case"JAZZ"->songEntities=songService.findJazzSongs();
            case"ROCK"-> songEntities=songService.findRockSongs();
        }
        return songEntities;
    }


}
