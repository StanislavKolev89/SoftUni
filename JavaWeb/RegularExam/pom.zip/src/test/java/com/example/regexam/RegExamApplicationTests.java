package com.example.regexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegExamApplicationTests {

    @Test
    void contextLoads() {
    }

}
